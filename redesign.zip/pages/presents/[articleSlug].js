import { useRouter } from "next/router";

export default function ArticlePage() {
    return (
        <h1>Article here</h1>
    );
}