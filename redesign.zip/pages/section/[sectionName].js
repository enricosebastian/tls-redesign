import { useRouter } from "next/router";

export default function SectionPage() {
    return (
        <h1>Section with Articles</h1>
    );
}